/*
* msh - A mini shell program with job control
*
* <Put your name and login ID here>
Jasper Lin - jasperl
Viren Velacheri - vtrain
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include "util.h"
#include "jobs.h"


/* Global variables */
int verbose = 0;            /* if true, print additional output */

extern char **environ;      /* defined in libc */
static char prompt[] = "msh> ";    /* command line prompt (DO NOT CHANGE) */
static struct job_t jobs[MAXJOBS]; /* The job list */
/* End global variables */


/* Function prototypes */

/* Here are the functions that you will implement */
void eval(char *cmdline);
int builtin_cmd(char **argv);
void do_bgfg(char **argv);
void waitfg(pid_t pid);

void sigchld_handler(int sig);
void sigtstp_handler(int sig);
int length_of_Nums(int jid, int pid); // helper method that we implemented
void sigint_handler(int sig);

/* Here are helper routines that we've provided for you */
void usage(void);
void sigquit_handler(int sig);



/*
* main - The shell's main routine
*/
int main(int argc, char **argv)
{
  char c;
  char cmdline[MAXLINE];
  int emit_prompt = 1; /* emit prompt (default) */

  /* Redirect stderr to stdout (so that driver will get all output
  * on the pipe connected to stdout) */
  dup2(1, 2);

  /* Parse the command line */
  while ((c = getopt(argc, argv, "hvp")) != EOF) {
    switch (c) {
      case 'h':             /* print help message */
      usage();
      break;
      case 'v':             /* emit additional diagnostic info */
      verbose = 1;
      break;
      case 'p':             /* don't print a prompt */
      emit_prompt = 0;  /* handy for automatic testing */
      break;
      default:
      usage();
    }
  }

  /* Install the signal handlers */

  /* These are the ones you will need to implement */
  Signal(SIGINT,  sigint_handler);   /* ctrl-c */
  Signal(SIGTSTP, sigtstp_handler);  /* ctrl-z */
  Signal(SIGCHLD, sigchld_handler);  /* Terminated or stopped child */

  /* This one provides a clean way to kill the shell */
  Signal(SIGQUIT, sigquit_handler);

  /* Initialize the job list */
  initjobs(jobs);

  /* Execute the shell's read/eval loop */
  while (1) {

    /* Read command line */
    if (emit_prompt) {
      printf("%s", prompt);
      fflush(stdout);
    }
    if ((fgets(cmdline, MAXLINE, stdin) == NULL) && ferror(stdin))
    app_error("fgets error");
    if (feof(stdin)) { /* End of file (ctrl-d) */
      fflush(stdout);
      exit(0);
    }

    /* Evaluate the command line */
    eval(cmdline);
    fflush(stdout);
    fflush(stdout);
  }

  exit(0); /* control never reaches here */
}

/*
* eval - Evaluate the command line that the user has just typed in
*
* If the user has requested a built-in command (quit, jobs, bg or fg)
* then execute it immediately. Otherwise, fork a child process and
* run the job in the context of the child. If the job is running in
* the foreground, wait for it to terminate and then return.  Note:
* each child process must have a unique process group ID so that our
* background children don't receive SIGINT (SIGTSTP) from the kernel
* when we type ctrl-c (ctrl-z) at the keyboard.
*/
void eval(char *cmdline)
{
  //Viren and Jasper both drove here
  // Below variables are the pid of potential child as well as the masks
  // for the different signal block sets.
  pid_t child;
  sigset_t mask, prev_mask, all_mask;
  char *argv[MAXARGS];
  int bgOrFG = parseline(cmdline, argv); // 0 if fg, 1 if bg
  sigemptyset(&mask); // empties set to block on.
  sigaddset(&mask, SIGCHLD); // adds SIGCHLD signal to block on,
  sigfillset(&all_mask); // essentially initializes the signal set.
  if (builtin_cmd(argv) == 0) {
    // blocks on all signals in SIG_BLOCK set which is just SIGCHLD.
    // It also sagves the previous blocked set.
    sigprocmask(SIG_BLOCK, &mask, &prev_mask);
    child = fork();
    //runs job in context of child
    if (child == 0) {
      // the below line sets the process group id of the calling process
      // to the calling process of the process ID of calling process.
      setpgid(0, 0);
      // the below line restores the previous blocked set which unblocks
      // SIGCHLD.
      sigprocmask(SIG_SETMASK, &prev_mask, NULL);
      // if the file path is not valid, we print that command was not
      // found and exit.
      if (execve(argv[0], argv, environ) == -1) {
        printf("%s: Command not found\n",  argv[0]);
        exit(0);
      }
    }
    // the below line restores the all blocked set. We then add the
    // job with the respective status. Then we restore the previous set.
    sigprocmask(SIG_SETMASK, &all_mask, NULL);
    addjob(jobs, child, 1 + bgOrFG, cmdline); //adding 1 as FG = 1 and BG = 2
    sigprocmask(SIG_SETMASK, &prev_mask, NULL);
    if (!bgOrFG) {
      waitfg(child); //wait if foreground
    }
    // If background job, we print out it's status.
    if (bgOrFG) {
      printf("[%d] (%d) %s", pid2jid(jobs, child), child, cmdline);
    }

  }
  return; // End of Jasper and Viren driving.
}


/*
* builtin_cmd - If the user has typed a built-in command then execute
*    it immediately.
* Return 1 if a builtin command was executed; return 0
* if the argument passed in is *not* a builtin command.
*/
int builtin_cmd(char **argv)
{
  //Viren and Jasper drove here
  //terminating shell
  const char* builtin = "quit";
  // If command is quit, we exit and return 1 for above eval function.
  if (strcmp(argv[0], builtin) == 0) {
    exit(0);
    return 1;
  }
  //lists jobs
  builtin = "jobs";
  // If command is jobs, simply list jobs via listjobs function and return 1
  // for above eval function to indicate that it is a builtin command.
  if (strcmp(argv[0], builtin) == 0) {
    listjobs(jobs);
    return 1;
  }
  //foreground / background - send to bgfg method
  // same idea as above ones except run our do_bgfg function.
  if (strcmp(argv[0], "fg") == 0 || strcmp(argv[0], "bg") == 0) {
    do_bgfg(argv);
    return 1;
  }

  // If none of the above builtin commands, 0 or false is returned.
  return 0;     /* not a builtin command */
  // End of Jasper and Viren Driving.
}

/*
* do_bgfg - Execute the builtin bg and fg commands
*/
void do_bgfg(char **argv)
{
  //Jasper and Viren drove here
  //handles case in which there is no arg after bg/fg
  if (argv[1] == NULL) {
    if (strcmp(argv[0], "bg") == 0) {
      printf("bg command requires PID or %%jobid argument\n");
    }
    if (strcmp(argv[0], "fg") == 0) {
      printf("fg command requires PID or %%jobid argument\n");
    }
    return;
  }
  int i = 0;
  char* pidOrJid = argv[1];
  int jid;
  pid_t jobPid;
  //checks that given arg is in correct pid or jid format
  if (strchr(pidOrJid, '%')) {
    i = 1;
  }
  // This loop goes through the whole second argument by user to check
  // and make sure that it is a number and not anything else inputted.
  // If any non number, we print the respective error message and then
  // return. Otherwise, continue to go through characters til end.
  while (i < strlen(pidOrJid)) {
    if (!isdigit(pidOrJid[i])) {
      if (strcmp(argv[0], "bg") == 0) {
        printf("bg: argument must be a PID or %%jobid\n");
      }
      if (strcmp(argv[0], "fg") == 0) {
        printf("fg: argument must be a PID or %%jobid\n");
      }
      return;
    }
    i++;
  }

  //converting jid to pid and interprets pid if given, checks if job exists
  if(strchr(pidOrJid, '%')) {
    // the below memmove method allows us to get the number without % part.
    char* jidString = memmove(pidOrJid, pidOrJid + 1, strlen(pidOrJid));
    jid = atoi(jidString); // converts string to number
    // use getjobjid function see if given jid exists. If not, print
    // respective message and return. Otherwise, we get the job and its
    // pid.
    if (getjobjid(jobs, jid) == NULL) {
      printf("%%%s: No such job\n", pidOrJid);
      return;
    }
    struct job_t *job = getjobjid(jobs, jid);
    jobPid = job -> pid;
  }
  else {
    jobPid = atoi(pidOrJid);
    // sees if given pid exists. If not respective message is printed and
    // then returned. Otherwise, nothing else is done.
    if (getjobpid(jobs, jobPid) == NULL) {
      printf("(%d): No such process\n", jobPid);
      return;
    }
  }

  //sends signal to job with given pid to restart
  if (strcmp(argv[0], "bg") == 0 || strcmp(argv[0], "fg") == 0) {
    // -1 is used to send signal to entire process group.
    kill(-1 * jobPid, SIGCONT);
    // if bg, we set the state to it, get the jid, and print the respective
    //status. Otherwise, we just change the state to foreground and then
    // call waitfg or suspend shell until signal is received.
    if (strcmp(argv[0], "bg") == 0) {
      getjobpid(jobs, jobPid) -> state = BG;
      jid = pid2jid(jobs, jobPid);
      printf("[%d] (%d) %s", jid, jobPid, getjobpid(jobs, jobPid) -> cmdline);
    } else {
      getjobpid(jobs, jobPid) -> state = FG;
      waitfg(jobPid);
    }
  }
  return;
  // End of Jasper and Viren driving.
}

/*
* waitfg - Block until process pid is no longer the foreground process
*/
void waitfg(pid_t pid)
{
  //Jasper start driving.
  sigset_t mask, prev_mask;
  sigemptyset(&mask); // clears signals to block on.
  sigaddset(&mask, SIGCHLD); // adds SIGCHLD signal to block on.
  //checks that given pid is in the foreground
  while (pid == fgpid(jobs)) {
    //blocking signals
    sigprocmask(SIG_BLOCK, &mask, &prev_mask);
    sigsuspend(&prev_mask);
    sigprocmask(SIG_SETMASK, &prev_mask, NULL);
  }
  // End of Jasper, Viren driving now.
}

/*****************
* Signal handlers
*****************/

/*
* sigchld_handler - The kernel sends a SIGCHLD to the shell whenever
*     a child job terminates (becomes a zombie), or stops because it
*     received a SIGSTOP or SIGTSTP signal. The handler reaps all
*     available zombie children, but doesn't wait for any other
*     currently running children to terminate.
*/
void sigchld_handler(int sig)
{
  // Viren and Jasper Drove here.
  int status;
  pid_t pid;
  int jid;
  sigset_t mask, prev_mask;
  const int terminated = 32; // length of first prompt
  const int stopped = 30; // length of second prompt
  char *buf; // malloced and freed based off the conditions below.
  int length;
  sigfillset(&mask);
  // while we wait for either a reaped or stopped child whose process id is
  // equal to the pid, we get the jid for respective pid and then if child
  // process wasn't stopped by a signal and it didn't terminate normally,
  // we print that it was terminated by signal 2. If not stopped by a signal
  // but it did terminate normally, then we block on block of signals in
  // SIG_BLOCK, delete the job, and then unblock at the end. Otherwise, if
  // stopped by a signal, change state of respective job to ST and the print
  // that it was stopped by signal 20.
  while (0 < (pid = waitpid(-1, &status, WNOHANG | WUNTRACED))) {
    jid = pid2jid(jobs, pid);
    if (!WIFSTOPPED(status)) {
      if (!WIFEXITED(status)) { //interrupt signal
        length = terminated + length_of_Nums(jid, pid);
        buf = malloc(sizeof(char) * length);
        sprintf(buf, "Job [%d] (%d) terminated by signal 2", jid, pid);
        puts(buf);
        free(buf);
      }
      sigprocmask(SIG_BLOCK, &mask, &prev_mask);
      deletejob(jobs, pid);
      sigprocmask(SIG_SETMASK, &prev_mask, NULL);
    }
    if (WIFSTOPPED(status)) { //terminal stop signal
      length = stopped + length_of_Nums(jid, pid);
      buf = malloc(sizeof(char) * length);
      getjobpid(jobs, pid) -> state = ST;
      sprintf(buf, "Job [%d] (%d) stopped by signal 20", jid, pid);
      puts(buf);
      free(buf);
    }
  }
  return; // End of Viren and Jasper driving.
}

/* A helper method used for finding total length of jid and pid.
jid and pid are the parameters. Returns the combined length.
*/
int length_of_Nums(int jid, int pid) {
  // Start of Viren driving.
  // Pretty straightforward loops that go through and get length.
  // only exceptions are when values are zero from start.
  // Then just add 1 to length and move on. no loop then.
  int length = 0;
  if (jid == 0) {
    length++;
  } else {
    while (jid != 0) {
      jid /= 10;
      length++;
    }
  }
  if (pid == 0) {
    length++;
  } else {
    while (pid != 0) {
      pid /= 10;
      length++;
    }
  }
  return length;
} // End of Viren driving, Jasper driving now.

/*
* sigint_handler - The kernel sends a SIGINT to the shell whenver the
*    user types ctrl-c at the keyboard.  Catch it and send it along
*    to the foreground job.
*/
void sigint_handler(int sig)
{
  // Jasper drove here
  pid_t currentfg = fgpid(jobs); //get foreground process to send SIGINT
  // if not foreground process, do nothing.
  if (currentfg != 0) {
    // with kill send signal to whole foreground process group.
    // if error, we print an error message.
    if (kill(-1 * currentfg, SIGINT) == -1) {
      printf("There is a kill error!!!");
    }
  }
  return; // End of Jasper driving, Viren driving now.
}

/*
* sigtstp_handler - The kernel sends a SIGTSTP to the shell whenever
*     the user types ctrl-z at the keyboard. Catch it and suspend the
*     foreground job by sending it a SIGTSTP.
*/
void sigtstp_handler(int sig)
{
  // Viren drove here.
  pid_t currentfg = fgpid(jobs); //get foreground process to send SIGSTP
  // if not foreground process, do nothing.
  if (currentfg != 0) {
    // with kill send signal to whole foreground process group.
    // if error, we print an error message.
    if (kill(-1 * currentfg, SIGTSTP) == -1) {
      printf("There is a kill error!!!");
    }
  }
  return; // End of Viren driving, Jasper driving now.
}

/*********************
* End signal handlers
*********************/



/***********************
* Other helper routines
***********************/

/*
* usage - print a help message
*/
void usage(void)
{
  printf("Usage: shell [-hvp]\n");
  printf("   -h   print this message\n");
  printf("   -v   print additional diagnostic information\n");
  printf("   -p   do not emit a command prompt\n");
  exit(1);
}

/*
* sigquit_handler - The driver program can gracefully terminate the
*    child shell by sending it a SIGQUIT signal.
*/
void sigquit_handler(int sig)
{
  ssize_t bytes;
  const int STDOUT = 1;
  bytes = write(STDOUT, "Terminating after receipt of SIGQUIT signal\n", 45);
  if(bytes != 45)
  exit(-999);
  exit(1);
}
