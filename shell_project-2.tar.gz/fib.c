#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

const int MAX = 13;

static void doFib(int n, int doPrint);


/*
* unix_error - unix-style error routine.
*/
inline static void unix_error(char *msg)
{
  fprintf(stdout, "%s: %s\n", msg, strerror(errno));
  exit(1);
}


int main(int argc, char **argv)
{
  int arg;
  int print=1;

  if(argc != 2){
    fprintf(stderr, "Usage: fib <num>\n");
    exit(-1);
  }

  arg = atoi(argv[1]);
  if(arg < 0 || arg > MAX){
    fprintf(stderr, "number must be between 0 and %d\n", MAX);
    exit(-1);
  }

  doFib(arg, print);

  return 0;
}

/*
* Recursively compute the specified number. If print is
* true, print it. Otherwise, provide it to my parent process.
*
* NOTE: The solution must be recursive and it must fork
* a new child for each call. Each process should call
* doFib() exactly once.
*/
static void doFib(int n, int doPrint)
{
  // Pretty much what this method does is fork a child for each n -1 and n - 2
  // call unless the n is 0 or 1. The exit statuses of each of these processes
  // is added together to get the sum that is then returned at the end as the
  // answer to what the nth number is in the fibonacci sequence.
  int status;
  int sum;
  pid_t pid1;
  pid_t pid2;
  // Jasper and Viren both drove throughout
  // 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144
  // base cases
  if(n <= 0){
    // This if will only be true if n is originally 0 or less to begin with
    // and doPrint is something other than 0 or true. Otherwise just exit with
    // a status of 0 or the base case value of 0.
    if(doPrint){
      printf("0\n");
    }
    exit(0);
  }
  if(n == 1){
    // This is similar to the above execpt where n is 1 to begin with and if
    // not, process just exits with a status of 1.
    if(doPrint) {
      printf("1\n");
    }
    exit(1);
  }
  //child 1 process created to handle n - 1 call.
  pid1 = fork();
  // if it is a child proces and n > 0, we make the n - 1 call with 0 as
  // doPrint to ensure no printing.
  if(pid1 == 0){
    if(n > 0){
      // for do print we pass in 0 so that the neither of the base cases
      // print out the base value as the original n is not 0 or 1.
      doFib(n - 1, 0);
    }
  }
  wait(&status); // parent waits til child process status comes back.
  // The below code gets the status of the n - 1 call and adds to the sum.
  int exit_status = WEXITSTATUS(status);
  sum += exit_status;  //get exit status of child to add to sum
  //child 2 - handles n - 2
  pid2 = fork();
  // same thing as for n - 1 call except for n - 2. Same idea as doPrint is
  // set to 0 to ensure no printing of value.
  if(pid2 == 0){
    if(n > 1){
      doFib(n - 2, 0);
    }
  }
  // use below call to wait til we can get back the status value of child.
  // Once we do, we get that value in exit status and add it to sum. May not
  // have neededd exit_status variable for storing value but included to make
  // code more readable.
  wait(&status);
  exit_status = WEXITSTATUS(status);
  sum += exit_status; //now both children added to sum
  // By this point, should have sum. Now we check if we print or not. Either
  // way, we exit the original parent process now with the final sum for
  // nth term.
  if(doPrint){
    printf("%d\n", sum);
  }
  exit(sum);
  // End drive for Jasper and Viren. We both drove here and manipulated the
  // code equally and didn't really have any distinct parts individually.
}
