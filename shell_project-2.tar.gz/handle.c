#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include "util.h"


/*
* First, print out the process ID of this process.
*
* Then, set up the signal handler so that ^C causes
* the program to print "Nice try.\n" and continue looping.
*
* Finally, loop forever, printing "Still here\n" once every
* second.
*/

/* This method handles the SIGINT or interrupt from the keyboard (Ctrl c).
In response, it just prints out "Nice try" and then a new line instead
or stopping/interrupting the current process.
*/
void sigIntHandler()
{
	// Viren drove here
	// We got this way of printing straight from project page.
	// Knew that printf is not safe for signal handler methods like this.
	ssize_t bytes;
	const int STDOUT = 1;
	bytes = write(STDOUT, "Nice try.\n", 10);
	if(bytes != 10){
	 exit(-999);
  }
	// End of Viren driving, Jasper driving now.
}

/* This method handles the SIGUSR signal where when caught, we print exiting
and then new line before exiting with a status of one.
*/
void sigUsrHandler()
{
	//Jasper drove here.
	// Same print format as above as printf is not safe for being used in
	// signal handlers. Only difference is what is printed or written out and
	// in addition an exiting with a value of 1.
	ssize_t bytes;
	const int STDOUT = 1;
	bytes = write(STDOUT, "exiting.\n", 10);
	if(bytes != 10){
	 exit(-999);
  }
	exit(1); // End of Jasper driving, Viren driving now.
}

/* The job of this main method is to print "Still Here" regardless of an
interrupt occuring. We used nanosleep and implemented the needed sleep time
structures to help with this.
*/
int main(int argc, char **argv)
{
	//Jasper and Viren drove here
	pid_t pid = getpid();
	//timespec struct to keep track of time for nanosleep
	// This first one stores one second and second stores zero as the difference
	// between the two is the remaining time or 1 second.
	struct timespec *sleepTime1 = malloc(sizeof(struct timespec));
	sleepTime1->tv_sec = 1;
	sleepTime1->tv_nsec = 0;
	struct timespec *sleepTime2 = malloc(sizeof(struct timespec));
	sleepTime2->tv_sec = 0;
	sleepTime2->tv_nsec = 0;

	printf("%d\n", pid);

	// The below if statements are used for error handling for both the
	// sigint as well as the sigusr handlers.
	if(signal(SIGINT, sigIntHandler) == SIG_ERR){
		unix_error("signal error");
	}
	if(signal(SIGUSR1, sigUsrHandler) == SIG_ERR){
		unix_error("signal error");
	}

	//continuous loop printing. "Still Here"printed every second regardless of an
	// interrupt.
	while (1) {
		printf("Still Here\n");
		// While there is an interrupt or nanosleep returns -1, the sleep time
		// 1 structure is changed to what the second sleep time stores to reflect
		// capture the time remaining when the interrupt occurred as the adjustment.
		while (nanosleep(sleepTime1, sleepTime2) == -1) {
			sleepTime1->tv_sec = sleepTime2->tv_sec;
			sleepTime1->tv_nsec = sleepTime2->tv_nsec;
		}
		// The below is done to reset the first sleep time to its normal one second
		// as there is no interrupts and it should work as normal.
		sleepTime1->tv_sec = 1;
		sleepTime1->tv_nsec = 0;
	}
	return 0; // Jasper and Viren finished driving, took a break.
}
