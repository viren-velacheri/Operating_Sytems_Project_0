#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>

//Jasper Drove Here
/* This method sends a signal to a process with the given pid. It does this
by using the kill command. In this case, we send the terminate signal or
SIGUSR
*/
void sendSig(pid_t pid)
{
	// the terminate or SIGUSR1 sent to given process.
	kill(pid, SIGUSR1);
}

/* This main method just gets the given pid id number and the terminate signal
is then sent to that respective process.
*/
int main(int argc, char **argv)
{
	// the below line gets the pid number as it is simply an integer so just
	// used atoi to get the value.
	pid_t pid = atoi(argv[1]);
	//sends signal through kill to given process
	sendSig(pid);
	return 0; // just returned 0 as default. really has no meaning.
	// End of Jasper driving, Viren driving now.
}
